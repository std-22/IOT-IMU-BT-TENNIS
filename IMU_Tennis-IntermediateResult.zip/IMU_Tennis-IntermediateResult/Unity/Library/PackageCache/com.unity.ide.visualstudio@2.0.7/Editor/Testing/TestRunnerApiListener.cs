version https://git-lfs.github.com/spec/v1
oid sha256:6a253ae938e7ad80c52e8fd426d746a5822ab053d73463c7f0b12f8038231f3d
size 1366
