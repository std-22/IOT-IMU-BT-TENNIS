version https://git-lfs.github.com/spec/v1
oid sha256:4973af64cab5c8b06f0069ba64975d4a788dfe3e4421f25931a1b94fc9813967
size 6480
