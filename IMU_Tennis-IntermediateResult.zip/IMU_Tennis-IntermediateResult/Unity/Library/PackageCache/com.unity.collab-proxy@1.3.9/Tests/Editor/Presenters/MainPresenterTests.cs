version https://git-lfs.github.com/spec/v1
oid sha256:27a7560f18b97d85976a24f192c1fa717cc87583be356e73ae1ecfb012707ebf
size 3573
