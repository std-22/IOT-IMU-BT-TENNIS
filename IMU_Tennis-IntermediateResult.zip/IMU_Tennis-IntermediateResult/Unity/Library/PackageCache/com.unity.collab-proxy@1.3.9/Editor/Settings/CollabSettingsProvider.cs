version https://git-lfs.github.com/spec/v1
oid sha256:cc63cbe1b99c94af2be3609f620f6310c9b0492294e787ddf0c26194a1c9866b
size 691
