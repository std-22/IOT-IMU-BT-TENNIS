version https://git-lfs.github.com/spec/v1
oid sha256:bedc7aa86bb174df13c13619cd6f10ac985a9b3d501ee44891f185f6c2b48192
size 3224
