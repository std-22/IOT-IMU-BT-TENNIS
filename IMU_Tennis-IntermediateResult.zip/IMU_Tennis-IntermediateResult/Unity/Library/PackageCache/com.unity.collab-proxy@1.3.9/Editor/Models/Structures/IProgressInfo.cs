version https://git-lfs.github.com/spec/v1
oid sha256:e47db92a8584b24e6d272880e5a6b2d376fcd4cd8ed743ed2f550d1e28a8eaed
size 431
