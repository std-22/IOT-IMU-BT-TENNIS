version https://git-lfs.github.com/spec/v1
oid sha256:b2a86b239514893d328437c18a46a9727a04c56cd1890f639f8f58ce790c36db
size 505
