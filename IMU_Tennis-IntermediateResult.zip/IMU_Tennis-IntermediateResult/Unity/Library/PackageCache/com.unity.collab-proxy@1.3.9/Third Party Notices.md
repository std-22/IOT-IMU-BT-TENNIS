version https://git-lfs.github.com/spec/v1
oid sha256:92b9c192a803c33b18c1c383840e6796f60eacfaf9fb65a4443bda5681c815b5
size 240
