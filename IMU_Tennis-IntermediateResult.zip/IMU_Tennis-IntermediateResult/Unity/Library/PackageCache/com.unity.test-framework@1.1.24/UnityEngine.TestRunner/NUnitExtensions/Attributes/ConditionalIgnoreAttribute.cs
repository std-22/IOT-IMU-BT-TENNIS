version https://git-lfs.github.com/spec/v1
oid sha256:ba7928d6b92d76fd6009f9280718fad58ae6216e12e625f2624b533a8d877e96
size 3419
