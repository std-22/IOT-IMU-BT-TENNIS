version https://git-lfs.github.com/spec/v1
oid sha256:6f06c52c6d77b061aeb829f52a00a8dc366301263804cde35b02a6cc68b1e3c3
size 6995
