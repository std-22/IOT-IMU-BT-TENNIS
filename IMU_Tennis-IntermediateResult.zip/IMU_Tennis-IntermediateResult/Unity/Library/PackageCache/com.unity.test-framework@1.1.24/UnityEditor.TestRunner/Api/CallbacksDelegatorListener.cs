version https://git-lfs.github.com/spec/v1
oid sha256:3c7f97d54b32fe49a1cae0284c8dd01ee39404d91dc78410e02f1cbea3102667
size 882
