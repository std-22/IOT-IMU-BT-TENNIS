version https://git-lfs.github.com/spec/v1
oid sha256:ee8c6fe38b12a0e9969ee82037e4af9a168e7b400c223915c4a68da62bf4d2c3
size 477
