version https://git-lfs.github.com/spec/v1
oid sha256:6745d15d86d81517c78453f8c2a2b8469b23f391be4cd5397397ce5779316b1d
size 414
