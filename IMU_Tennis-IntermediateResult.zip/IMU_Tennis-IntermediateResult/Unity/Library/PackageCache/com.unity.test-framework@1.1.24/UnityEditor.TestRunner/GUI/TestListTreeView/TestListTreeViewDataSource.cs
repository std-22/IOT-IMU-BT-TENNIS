version https://git-lfs.github.com/spec/v1
oid sha256:6a36ec03d39129f2a4021436f43eee3838c3fb3e59e8cf49b116640ffbf7eed1
size 3467
