version https://git-lfs.github.com/spec/v1
oid sha256:1ac66f39090946bd84b3c8a26eab0052ca492e9bba6fdec5a5efaf84970181be
size 6625
