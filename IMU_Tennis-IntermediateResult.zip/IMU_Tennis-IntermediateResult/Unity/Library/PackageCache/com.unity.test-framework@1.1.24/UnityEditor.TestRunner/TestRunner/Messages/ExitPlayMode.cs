version https://git-lfs.github.com/spec/v1
oid sha256:609049654644f6c0ce30ec2b69fe0077d3247cfd2022c04e8b944c36cfacaba2
size 1616
