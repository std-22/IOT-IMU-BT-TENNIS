version https://git-lfs.github.com/spec/v1
oid sha256:2d11ebbf5088d9454d7e2abda4cd9136a125d6ff57c9ddaab8a6ac729c1f6505
size 340
