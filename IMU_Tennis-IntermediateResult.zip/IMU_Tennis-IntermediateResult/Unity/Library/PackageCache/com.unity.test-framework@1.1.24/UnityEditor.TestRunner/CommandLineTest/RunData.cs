version https://git-lfs.github.com/spec/v1
oid sha256:86f08681b6a772394037982874f60547bf31a13785dfdef85844989bc9cefe70
size 224
