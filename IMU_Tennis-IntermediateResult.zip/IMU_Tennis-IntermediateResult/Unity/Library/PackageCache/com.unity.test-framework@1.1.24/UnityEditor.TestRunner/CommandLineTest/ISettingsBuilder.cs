version https://git-lfs.github.com/spec/v1
oid sha256:9b772ef98fb89b0f3d93db0e23ac142ae3da66e37bce9587feb1b6f868ca0d14
size 320
