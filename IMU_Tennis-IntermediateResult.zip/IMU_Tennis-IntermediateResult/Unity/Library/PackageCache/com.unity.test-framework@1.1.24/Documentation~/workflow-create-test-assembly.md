version https://git-lfs.github.com/spec/v1
oid sha256:66d7a43d0e98db77fa491166760a0d2a2dfb00ceae33622352415324c80d95fe
size 1350
