version https://git-lfs.github.com/spec/v1
oid sha256:5b0870d609b9d2d522ada429e7659962675cfb928c4bca85fe80b1f3f5c13517
size 1687
