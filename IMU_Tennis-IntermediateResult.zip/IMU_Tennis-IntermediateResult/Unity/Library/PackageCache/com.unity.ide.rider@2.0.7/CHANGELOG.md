version https://git-lfs.github.com/spec/v1
oid sha256:8eb225a03b738ca986ad7032629b3aae6b93f117d583dc88ffa54b4c500d85dc
size 4144
