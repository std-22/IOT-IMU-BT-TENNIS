version https://git-lfs.github.com/spec/v1
oid sha256:0b0147e50ba1e6d00347cb1491666b72b96e068a4b186a67f1764a4484cbbcea
size 1025
