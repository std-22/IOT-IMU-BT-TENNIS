version https://git-lfs.github.com/spec/v1
oid sha256:c6ff52ad31502134ea25b8fa084906b57434ae6f4a43ddf50a174d836372dd3b
size 405
