version https://git-lfs.github.com/spec/v1
oid sha256:ea5652577905478a2cee71afe144bfe792db9666ba171acc76d1b5eb21604aa5
size 372
