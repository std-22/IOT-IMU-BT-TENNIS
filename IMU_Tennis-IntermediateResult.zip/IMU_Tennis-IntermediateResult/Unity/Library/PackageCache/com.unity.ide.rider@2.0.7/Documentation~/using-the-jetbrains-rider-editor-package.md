version https://git-lfs.github.com/spec/v1
oid sha256:69383edee8fad9de554c38b501428de7387f1a10f55af3054560f3d8e344a9db
size 6301
