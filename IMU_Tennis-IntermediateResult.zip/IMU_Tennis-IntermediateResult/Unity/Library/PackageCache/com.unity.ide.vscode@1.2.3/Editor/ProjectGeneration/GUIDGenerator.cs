version https://git-lfs.github.com/spec/v1
oid sha256:1a2c17f11e4e8303fa0151ecf4bbe58c9770a6544ed9b10ba8430d43310b60ae
size 671
